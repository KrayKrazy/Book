
import { GoogleGenAI, Chat } from "@google/genai";
import { MARIANA_SYSTEM_INSTRUCTION } from "../constants";

let chatSession: Chat | null = null;

export const startNewChat = async (): Promise<string> => {
  const ai = new GoogleGenAI({ apiKey: process.env.API_KEY || '' });
  
  chatSession = ai.chats.create({
    model: 'gemini-3-flash-preview',
    config: {
      systemInstruction: MARIANA_SYSTEM_INSTRUCTION,
      temperature: 0.4,
    },
  });

  return "Chat session initialized";
};

export const sendMessageToGemini = async (message: string): Promise<string> => {
  if (!chatSession) {
    await startNewChat();
  }
  
  if (!chatSession) throw new Error("Failed to initialize chat session");

  try {
    const response = await chatSession.sendMessage({
      message: message
    });
    
    return response.text || "Perdoe-me, a conexão falhou. Poderia repetir?";
  } catch (error) {
    console.error("Gemini API Error:", error);
    // Re-initialize on serious error
    await startNewChat();
    return "Tive um lapso na análise tática. Pode reenviar o que o cliente disse?";
  }
};
